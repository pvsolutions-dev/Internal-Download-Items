from flask import Flask, jsonify, render_template, request, send_from_directory, make_response, g
from flask_cors import CORS
import os
import json
from datetime import datetime, timezone, timedelta
from uuid import uuid4
import jwt
import re
from functools import wraps

app = Flask(__name__, template_folder='templates', static_folder='static')
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-in-prod")
CORS(app)

# --- Server Config ---
HOST="127.0.0.1"
PORT=8000
DEBUG=True

# --- JWT Config ---
JWT_SECRET = os.environ.get("JWT_SECRET", "your-super-secret-jwt-key-change-me-in-prod")
JWT_ALG = "HS256"
JWT_TTL_HOURS = 24
app.config['SECRET_KEY'] = JWT_SECRET  # Make Flask use same secret

# --- Data files ---
DATA_DIR = 'data'
USERS_FILE = os.path.join(DATA_DIR, 'users.json')
TASKS_FILE = os.path.join(DATA_DIR, 'tasks.json')
os.makedirs(DATA_DIR, exist_ok=True)

# Initialize files
if not os.path.exists(USERS_FILE): 
    json.dump({"users": []}, open(USERS_FILE, 'w'), indent=2)
if not os.path.exists(TASKS_FILE): 
    json.dump({"tasks": []}, open(TASKS_FILE, 'w'), indent=2)

# --- JWT + Auth Helpers ---
def create_jwt_token(user_id: str):
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(hours=JWT_TTL_HOURS)).timestamp())
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

def verify_jwt_token(token: str):
    try: 
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

def get_user_id_from_request():
    # Bearer token first (API tools)
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:].strip()
        payload = verify_jwt_token(token)
        if payload: return payload.get("sub")
    
    # httpOnly cookie (browsers)
    cookie_token = request.cookies.get("access_token")
    if cookie_token:
        payload = verify_jwt_token(cookie_token)
        if payload: return payload.get("sub")
    
    return None  # null user_id for not logged in

def require_auth(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = get_user_id_from_request()
        if not user_id:
            return jsonify({"error": "verification needed"}), 401
        g.auth_user_id = user_id  # ← Flask global
        return f(*args, **kwargs)  # ← NO signature changes!
    return decorated_function

# --- Data helpers ---
def _load_json(path, root_key):
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    if root_key not in data or not isinstance(data[root_key], list):
        data[root_key] = []
    return data

def _save_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def load_users(): return _load_json(USERS_FILE, 'users')
def save_users(data): _save_json(USERS_FILE, data)
def load_tasks(): return _load_json(TASKS_FILE, 'tasks')
def save_tasks(data): _save_json(TASKS_FILE, data)

def normalize_task_timestamps(tasks):
    for t in tasks:
        if 'lastUpdated' in t and 'last_modified' not in t:
            t['last_modified'] = t['lastUpdated']
    return tasks

def get_or_create_user(user_id: str, display_name: str | None = None):
    users_data = load_users()
    users = users_data['users']
    user = next((u for u in users if u.get('id') == user_id), None)
    if not user:
        user = {
            "id": user_id, 
            "display_name": display_name or user_id, 
            "tasks": []
        }
        users.append(user)
        save_users(users_data)
    return user, users_data

def new_task_id(): 
    return uuid4().hex[:12]

def get_user_by_id(user_id):
    """Get user data from JSON file"""
    users_data = load_users()
    users = users_data['users']
    return next((u for u in users if u.get('id') == user_id), None)


def get_user_tasks(user_id):
    """Get user's tasks from JSON file"""
    users_data = load_users()
    user = next((u for u in users_data['users'] if u.get('id') == user_id), None)
    if not user or 'tasks' not in user:
        return []
    
    tasks_data = load_tasks()
    tasks = tasks_data['tasks']
    user_task_ids = user['tasks']
    return [t for t in tasks if t.get('id') in user_task_ids]

# --- AUTH ROUTES ---
@app.route('/auth/me', methods=['GET'])
def auth_me():
    user_id = get_user_id_from_request()
    if not user_id:
        return jsonify({"user_id": None, "display_name": None})
    
    user, _ = get_or_create_user(user_id)
    return jsonify({
        "user_id": user_id,
        "display_name": user.get("display_name")
    })

@app.route('/auth/login', methods=['POST'])
def auth_login():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    
    if not username or not password:
        return jsonify({"error": "username and password required"}), 400
    
    # 1. FIND EXISTING USER BY DISPLAY_NAME first
    users_data = load_users()
    users = users_data['users']
    
    existing_user = next((u for u in users if u.get('display_name', '').lower() == username.lower()), None)
    
    if existing_user:
        user_id = existing_user['id']  # Use existing UUID ✅
        user = existing_user
    else:
        # 2. CREATE NEW USER with UUID
        user_id = uuid4().hex[:12]
        user = {
            "id": user_id,
            "display_name": username,
            "tasks": [],
            "password_hash": None  # Will be set below
        }
        users.append(user)
        save_users(users_data)
    
    # 3. PASSWORD CHECK
    import hashlib
    input_hash = hashlib.sha256(password.encode()).hexdigest()
    stored_hash = user.get('password_hash')
    
    if stored_hash and stored_hash != input_hash:
        return jsonify({"error": "invalid credentials"}), 401
    
    # 4. SAVE PASSWORD HASH (first login or new user)
    if not stored_hash:
        user['password_hash'] = input_hash
        save_users(users_data)
    
    # 5. ISSUE JWT + COOKIE
    token = create_jwt_token(user_id)
    resp = make_response(jsonify({
        "success": True,
        "user_id": user_id,        # UUID for URL
        "display_name": username   # For UI
    }))
    
    resp.set_cookie('access_token', token, max_age=JWT_TTL_HOURS*3600, httponly=True, samesite='lax')
    return resp

@app.route('/auth/logout', methods=['POST'])
def auth_logout():
    resp = make_response(jsonify({"success": True}))
    resp.delete_cookie('access_token')
    return resp

@app.route('/auth/settings', methods=['GET', 'POST'])
@require_auth
def auth_settings(**kwargs):
    user_id = g.auth_user_id  # ← FIXED: Use g.auth_user_id
    user, users_data = get_or_create_user(user_id)  
    
    if request.method == 'GET':
        return jsonify({
            "user_id": user_id,
            "display_name": user.get("display_name"),
            "has_password": bool(user.get("password_hash"))
        })
    
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
        new_password = data.get("new_password")
        if not new_password or len(new_password) < 4:
            return jsonify({"error": "password too short"}), 400
        
        import hashlib
        user["password_hash"] = hashlib.sha256(new_password.encode()).hexdigest()
        save_users(users_data)
        return jsonify({"success": True})

# --- PROTECTED API (user_id from URL must match JWT) ---
@app.route('/api/user/<user_id>', methods=['GET'])
@require_auth
def api_get_user(user_id, **kwargs):
    if user_id != g.auth_user_id:
        return jsonify({"error": "unauthorized"}), 403
    
    # Get user from JSON
    users_data = load_users()
    user = next((u for u in users_data['users'] if u.get('id') == user_id), None)
    if not user:
        return jsonify({"error": "user not found"}), 404
    
    # Get user's tasks
    tasks = get_user_tasks(user_id)
    
    return jsonify({
        "user": user,
        "tasks": tasks
    })

@app.route('/api/test-jwt', methods=['GET'])
def test_jwt():
    user_id = get_user_id_from_request()
    return jsonify({"user_id_from_cookie": user_id})

@app.route('/api/user/<user_id>/new', methods=['POST'])
@require_auth
def api_create_task(user_id, **kwargs):  # Accepts kwargs
    if user_id != g.auth_user_id:  # ← FIXED: Use g.auth_user_id  
        return jsonify({"error": "verification needed"}), 403
    
    user, users_data = get_or_create_user(user_id)
    tasks_data = load_tasks()
    tasks = tasks_data['tasks']
    
    payload = request.get_json(silent=True) or {}
    existing_ids = {t.get('id') for t in tasks}
    new_id = payload.get('id') or new_task_id()
    while new_id in existing_ids: 
        new_id = new_task_id()
    
    now_iso = datetime.now(timezone.utc).isoformat()
    new_task = {
        "id": new_id,
        "category": payload.get("category", "General"),
        "status": payload.get("status", "New"),
        "title": payload.get("title", "New Task"),
        "description": payload.get("description", ""),
        "priority": payload.get("priority", "Medium"),
        "deadline": payload.get("deadline", ""),
        "content": payload.get("content", ""),
        "lastUpdated": now_iso,
        "last_modified": now_iso
    }
    
    tasks.append(new_task)
    save_tasks(tasks_data)
    user.setdefault('tasks', []).append(new_id)
    save_users(users_data)
    
    return jsonify({"success": True, "task": new_task}), 201

@app.route('/api/user/<user_id>/<task_id>', methods=['PUT', 'DELETE'])
@require_auth
def api_task_crud(user_id, task_id, **kwargs):
    if user_id != g.auth_user_id:  # ← FIXED: Use g.auth_user_id 
        return jsonify({"error": "verification needed"}), 403
    
    user, users_data = get_or_create_user(user_id)
    tasks_data = load_tasks()
    tasks = tasks_data['tasks']
    
    if request.method == 'PUT':
        task = next((t for t in tasks if t.get('id') == task_id), None)
        if not task:
            task = {"id": task_id}
            tasks.append(task)
            if task_id not in user.setdefault('tasks', []):
                user['tasks'].append(task_id)
        
        payload = request.get_json(silent=True) or {}
        for k, v in payload.items(): 
            task[k] = v
        task["last_modified"] = datetime.now(timezone.utc).isoformat()
        save_tasks(tasks_data)
        save_users(users_data)
        return jsonify({"success": True, "task": task})
    
    elif request.method == 'DELETE':
        new_tasks = [t for t in tasks if t.get('id') != task_id]
        deleted = len(tasks) - len(new_tasks)
        tasks_data['tasks'] = new_tasks
        save_tasks(tasks_data)
        if deleted:
            user['tasks'] = [tid for tid in user.get('tasks', []) if tid != task_id]
            save_users(users_data)
        return jsonify({"success": True, "deleted": bool(deleted)})

# --- Frontend routes (public) ---
@app.route('/')
def serve_root(): 
    return render_template('main.html')

@app.route('/<user_id>')
@app.route('/<user_id>/')
@app.route('/<user_id>/<task_id>')
@app.route('/<user_id>/<task_id>/')
def serve_frontend(user_id=None, task_id=None):
    if task_id: 
        return render_template('task.html')
    return render_template('index.html')

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(
        os.path.join(app.root_path, 'static'), 
        'favicon.ico', 
        mimetype='image/vnd.microsoft.icon'
    )

if __name__ == '__main__':
    app.run(debug=DEBUG, port=PORT, host=HOST)
