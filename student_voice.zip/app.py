from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding as rsa_padding
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding as aes_padding
import base64
import json
import os
from datetime import datetime

app = Flask(__name__, template_folder='templates', static_folder='static')
CORS(app)

# --- 1. RSA & AES SETUP ---
private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
public_key = private_key.public_key()
public_pem = public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
).decode('utf-8')

AES_SESSION_KEY = os.urandom(32) 

# --- 2. STORAGE PATHS ---
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
REPORTS_FILE = os.path.join(DATA_DIR, "reports.json")
STUDENT_CREDS = os.path.join(DATA_DIR, "creds.json")
ADMIN_CREDS = os.path.join(DATA_DIR, "admincreds.json")

# Ensure files exist
for f_path in [REPORTS_FILE, STUDENT_CREDS, ADMIN_CREDS]:
    if not os.path.exists(f_path):
        with open(f_path, "w") as f: json.dump([], f)

# --- 3. CRYPTO HELPERS ---

def decrypt_rsa(encrypted_b64):
    """Decrypts RSA-OAEP data from browser."""
    try:
        encrypted_data = base64.b64decode(encrypted_b64)
        decrypted = private_key.decrypt(
            encrypted_data,
            rsa_padding.OAEP(
                mgf=rsa_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        return decrypted.decode('utf-8')
    except Exception as e:
        print(f"Decryption Error: {e}")
        return None

def encrypt_aes_cbc(plaintext):
    """Encrypts reports list for the Admin dashboard."""
    padder = aes_padding.PKCS7(128).padder()
    padded_data = padder.update(plaintext.encode('utf-8')) + padder.finalize()
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(AES_SESSION_KEY), modes.CBC(iv))
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
    return base64.b64encode(iv + ciphertext).decode('utf-8')

def load_db(file_path):
    with open(file_path, "r") as f:
        return json.load(f)

# --- 4. ROUTES ---

@app.route('/get_public_key', methods=['GET'])
def get_key():
    return jsonify({"public_key": public_pem})

@app.route('/verify', methods=['POST'])
def verify():
    data = request.json
    email = decrypt_rsa(data.get("email"))
    id_val = decrypt_rsa(data.get("studentID"))

    students = load_db(STUDENT_CREDS)
    admins = load_db(ADMIN_CREDS)

    # Valid if in student OR admin JSON
    is_valid = any(s['email'] == email and s['id'] == id_val for s in students) or \
               any(a['email'] == email and a['id'] == id_val for a in admins)
    
    return jsonify({"isValid": is_valid})

@app.route('/submit', methods=['POST'])
def submit():
    data = request.json
    email = decrypt_rsa(data.get("email"))
    id_val = decrypt_rsa(data.get("studentID"))

    students = load_db(STUDENT_CREDS)
    admins = load_db(ADMIN_CREDS)
    
    # Auth check before allowing report save
    authorized = any(s['email'] == email and s['id'] == id_val for s in students) or \
                 any(a['email'] == email and a['id'] == id_val for a in admins)

    if not authorized:
        return jsonify({"error": "Unauthorized"}), 403

    report = {
        "timestamp": datetime.now().isoformat(),
        "type": data.get("type"),
        "category": data.get("category"),
        "location": data.get("location"),
        "message": data.get("message"),
        "anonymous": data.get("anonymous"),
        "solved": False,
        "solved_by": None,
        "identity": {"email": email, "id": id_val} if not data.get("anonymous") else None
    }

    reports = load_db(REPORTS_FILE)
    reports.append(report)
    with open(REPORTS_FILE, "w") as f: json.dump(reports, f, indent=4)
    return jsonify({"status": "success"})

@app.route('/verify_staff', methods=['POST'])
def verify_staff():
    data = request.json
    email = decrypt_rsa(data.get("email"))
    password = decrypt_rsa(data.get("password"))

    admins = load_db(ADMIN_CREDS)
    # Admin login specifically checks admincreds.json
    is_admin = any(a['email'] == email and a['id'] == password for a in admins)

    if is_admin:
        return jsonify({
            "isValid": True,
            "session_key": base64.b64encode(AES_SESSION_KEY).decode('utf-8')
        })
    return jsonify({"isValid": False}), 401

@app.route('/get_reports', methods=['GET'])
def get_reports():
    reports = load_db(REPORTS_FILE)
    payload = encrypt_aes_cbc(json.dumps(reports))
    return jsonify({"payload": payload})

@app.route('/mark_solved', methods=['POST'])
def mark_solved():
    data = request.json
    idx = data.get('index')
    reports = load_db(REPORTS_FILE)
    if 0 <= idx < len(reports):
        reports[idx]['solved'] = True
        reports[idx]['solved_by'] = data.get('solved_by')
        with open(REPORTS_FILE, "w") as f: json.dump(reports, f, indent=4)
        return jsonify({"status": "success"})
    return jsonify({"status": "failed"}), 400

@app.route('/')
def index(): return render_template('index.html')

@app.route('/admin')
def admin(): return render_template('admin.html')

if __name__ == '__main__':
    app.run(host="127.0.0.1", port=55000, debug=True, use_reloader=False)