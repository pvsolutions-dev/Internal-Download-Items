from flask import Flask, request, render_template
from flask_cors import CORS
import zipfile
import io
import os

# Setup Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DOWNLOAD_DIR = os.path.join(BASE_DIR, "decrypted files")
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")

app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)
CORS(app) 

if not os.path.exists(DOWNLOAD_DIR):
    os.makedirs(DOWNLOAD_DIR)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload-decrypted', methods=['POST'])
def upload_decrypted():
    zip_data = request.data
    try:
        zip_buffer = io.BytesIO(zip_data)
        with zipfile.ZipFile(zip_buffer, 'r') as zip_ref:
            zip_ref.extractall(DOWNLOAD_DIR)
        
        # This line automatically opens the folder in Windows Explorer
        os.startfile(DOWNLOAD_DIR)
            
        return f"Successfully extracted to {DOWNLOAD_DIR}", 200
    except Exception as e:
        return f"Error: {str(e)}", 500

if __name__ == '__main__':
    app.run(port=15000)