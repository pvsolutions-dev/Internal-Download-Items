let selectedFolderEntries = [];
let selectedVaultFile = null;
const statusMsg = document.getElementById('statusMsg');
const loader = document.getElementById('loader');

window.onload = () => {
if (!window.isSecureContext) {
statusMsg.innerHTML = "<b style='color:red;'>Error: Not in a Secure Context.</b> Access via {{ request.host_url }}";
}
};
function toggleLoader(show) {
loader.style.display = show ? "block" : "none";
}

function setupZone(id, isFolder) {
const zone = document.getElementById(id);
['dragenter', 'dragover', 'dragleave', 'drop'].forEach(name => {
zone.addEventListener(name, e => { e.preventDefault(); e.stopPropagation(); });
});

zone.addEventListener('dragover', () => zone.classList.add('hover'));
zone.addEventListener('dragleave', () => zone.classList.remove('hover'));

zone.addEventListener('drop', async (e) => {
zone.classList.remove('hover');
statusMsg.style.color = "#666";

if (isFolder) {
const items = e.dataTransfer.items;
selectedFolderEntries = [];
for (let item of items) {
let entry = item.webkitGetAsEntry();
if (entry && entry.isDirectory) {
selectedFolderEntries.push(entry);
statusMsg.innerText = "Folder '" + entry.name + "' loaded.";
}
}
if (selectedFolderEntries.length === 0) {
statusMsg.innerText = "Error: Drop a FOLDER here.";
statusMsg.style.color = "red";
}
} else {
const file = e.dataTransfer.files[0];
if (file && file.name.endsWith('.jsencrypt')) {
selectedVaultFile = file;
statusMsg.innerText = "File '" + file.name + "' loaded.";
statusMsg.style.color = "#2ecc71";
} else {
selectedVaultFile = null;
statusMsg.innerText = "Error: Only .jsencrypt files allowed!";
statusMsg.style.color = "red";
}
}
});
}

setupZone('enc-drop-zone', true);
setupZone('dec-drop-zone', false);

async function getKey(password) {
const enc = new TextEncoder();
const hash = await crypto.subtle.digest('SHA-256', enc.encode(password));
return await crypto.subtle.importKey('raw', hash, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}

async function startEncryption() {
const password = document.getElementById('encryptPass').value;
const customName = document.getElementById('fileName').value.trim() || "vault";

if (selectedFolderEntries.length === 0 || !password) return alert("Select folder and set password!");

toggleLoader(true);
statusMsg.innerText = "Zipping folder...";
const zip = new JSZip();

async function addEntryToZip(entry, path = "") {
if (entry.isFile) {
const file = await new Promise(res => entry.file(res));
zip.file(path + entry.name, file);
} else if (entry.isDirectory) {
const reader = entry.createReader();
const entries = await new Promise(res => reader.readEntries(res));
for (let e of entries) await addEntryToZip(e, path + entry.name + "/");
}
}

try {
for (let entry of selectedFolderEntries) await addEntryToZip(entry);
const zipBlob = await zip.generateAsync({type: "uint8array"});

statusMsg.innerText = "Encrypting...";
const key = await getKey(password);
const iv = crypto.getRandomValues(new Uint8Array(12));
const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, zipBlob);

const a = document.createElement('a');
a.href = URL.createObjectURL(new Blob([iv, new Uint8Array(encrypted)]));
a.download = customName + ".jsencrypt";
a.click();

statusMsg.innerText = "Encryption successful!";
} catch (e) {
alert("Encryption error: " + e.message);
} finally {
toggleLoader(false);
}
}

async function startDecryption() {
const password = document.getElementById('decryptPass').value;
if (!selectedVaultFile || !password) return alert("Drop a .jsencrypt file and enter password!");

toggleLoader(true);
statusMsg.innerText = "Decrypting...";
const data = new Uint8Array(await selectedVaultFile.arrayBuffer());
const iv = data.slice(0, 12);
const ciphertext = data.slice(12);

try {
const key = await getKey(password);
const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ciphertext);

statusMsg.innerText = "Sending to Flask server...";
const response = await fetch('/upload-decrypted', { method: 'POST', body: decrypted });
const result = await response.text();

statusMsg.innerText = "Success! Folder created.";
statusMsg.style.color = "#2ecc71";
} catch (e) {
alert("Decryption failed. Check password.");
statusMsg.innerText = "Error: Access Denied.";
statusMsg.style.color = "red";
} finally {
toggleLoader(false);
}
}

function resetPage() {
selectedFolderEntries = [];
selectedVaultFile = null;
document.getElementById('fileName').value = "";
document.getElementById('encryptPass').value = "";
document.getElementById('decryptPass').value = "";
statusMsg.innerText = "Page Reset.";
statusMsg.style.color = "#666";
}