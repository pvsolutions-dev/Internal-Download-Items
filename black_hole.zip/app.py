import numpy as np
import moderngl
import moderngl_window as mglw
import struct
import ctypes
import os
import sys

# ---- Config ----
BASEPATH = os.path.dirname(os.path.abspath(__file__))
shader_path = os.path.join(BASEPATH, 'shader.comp')
icon_path = os.path.join(BASEPATH, 'icon.png')
ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("pvsolutions.blackhole.blackholrender.v1-0-0") # This line tells Windows to treat this script as its own AppID
ctypes.windll.shcore.SetProcessDpiAwareness(1) # Force Windows to not scale the window (Pixel Perfect)

class BlackHoleSim(mglw.WindowConfig):
    gl_version = (4, 3)
    title = "Black Hole Geodesic Simulator"
    window_size = (800, 600)
    aspect_ratio = 800 / 600

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        try:
            # This works for the pyglet/SDL2 backends
            self.wnd.set_icon(icon_path) 
        except Exception as e:
            print(f"Could not load icon: {e}")

        with open(shader_path, 'r') as f:
            self.compute_shader = self.ctx.compute_shader(f.read())

        self.texture = self.ctx.texture(self.window_size, 4)
        
        self.cam_buffer = self.ctx.buffer(reserve=struct.calcsize('16f 2f i i'))
        self.cam_buffer.bind_to_uniform_block(1)

        self.disk_buffer = self.ctx.buffer(struct.pack('4f', 15.0, 40.0, 0.0, 1.0))
        self.disk_buffer.bind_to_uniform_block(2)

        self.obj_buffer = self.ctx.buffer(struct.pack('i 12x 64f 64f 16f', 0, *([0.0]*144)))
        self.obj_buffer.bind_to_uniform_block(3)

        self.quad_program = self.ctx.program(
            vertex_shader='''
                #version 330
                in vec3 in_position;
                in vec2 in_texcoord_0;
                out vec2 v_texcoord;
                void main() {
                    v_texcoord = in_texcoord_0;
                    gl_Position = vec4(in_position, 1.0);
                }
            ''',
            fragment_shader='''
                #version 330
                uniform sampler2D tex;
                in vec2 v_texcoord;
                out vec4 f_color;
                void main() {
                    f_color = texture(tex, v_texcoord);
                }
            '''
        )
        self.quad_vao = mglw.geometry.quad_2d()

        # Camera state
        self.cam_pos = np.array([0.0, 5.0, -60.0])
        self.look_at = np.array([0.0, 0.0, 0.0])
        self.moving = False

    def key_event(self, key, action, modifiers):
        if action == self.wnd.keys.ACTION_PRESS:
            self.moving = True
        elif action == self.wnd.keys.ACTION_RELEASE:
            self.moving = False

    def on_render(self, time, frame_time):
        self.ctx.clear(0.0, 0.0, 0.0)

        # Basic rotation movement to prove it's rendering
        # If you press 'D', we rotate the camera around the Y axis
        move_speed = 1.0 * frame_time
        self.moving = False

        if self.wnd.is_key_pressed(self.wnd.keys.D):
            angle = 0.05
            curr_x, curr_z = self.cam_pos[0], self.cam_pos[2]
            self.cam_pos[0] = curr_x * np.cos(angle) - curr_z * np.sin(angle)
            self.cam_pos[2] = curr_x * np.sin(angle) + curr_z * np.cos(angle)
            self.moving = True

        if self.wnd.is_key_pressed(self.wnd.keys.A):
            angle = -0.05
            curr_x, curr_z = self.cam_pos[0], self.cam_pos[2]
            self.cam_pos[0] = curr_x * np.cos(angle) - curr_z * np.sin(angle)
            self.cam_pos[2] = curr_x * np.sin(angle) + curr_z * np.cos(angle)
            self.moving = True

        if self.wnd.is_key_pressed(self.wnd.keys.W):
            self.cam_pos *= 0.98 # Zoom in
            self.moving = True
        
        if self.wnd.is_key_pressed(self.wnd.keys.S):
            self.cam_pos *= 1.02 # Zoom out
            self.moving = True

        # Re-calculate vectors
        forward = -self.cam_pos / np.linalg.norm(self.cam_pos)
        right = np.cross(np.array([0, 1, 0]), forward)
        right /= np.linalg.norm(right)
        up = np.cross(forward, right)

        # Send to GPU
        data = struct.pack('16f 2f i i',
            *self.cam_pos, 0.0,
            *right, 0.0,
            *up, 0.0,
            *forward, 0.0,
            0.5, self.aspect_ratio, 
            1 if self.moving else 0, 0
        )
        self.cam_buffer.write(data)

        # Run Shader
        self.texture.bind_to_image(0, read=False, write=True)
        self.compute_shader.run(800//16, 600//16)

        # Present to screen
        self.texture.use(0)
        self.quad_vao.render(self.quad_program)

if __name__ == '__main__':
    mglw.run_window_config(BlackHoleSim)