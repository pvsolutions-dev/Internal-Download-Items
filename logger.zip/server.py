import json
import os
import datetime
import glob
import re
from flask import Flask, request, render_template, jsonify
from flask_socketio import SocketIO, emit

DATA_DIR = "data"

# Ensure the directory exists so the app doesn't crash when saving
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

app = Flask(__name__, template_folder="templates", static_folder="static")
socketio = SocketIO(app, cors_allowed_origins="*")

def get_log_files():
    # FIX 1: Look inside the /data folder for .json files
    search_path = os.path.join(DATA_DIR, "*.json")
    files = glob.glob(search_path)
    
    # FIX 2: Strip the "data/" path prefix so the ID is just "2026-01-19"
    raw_dates = [os.path.basename(f).replace('.json', '') for f in files]
    raw_dates.sort(reverse=True)
    
    formatted_files = []
    for f in raw_dates:
        formatted_files.append({
            "raw": f,
            "display": f.replace("-", " ") 
        })
    return formatted_files

def fix_iso_format(text):
    return re.sub(r'(\d)T(\d)', r'\1 \2', text)

@app.route('/api/log', methods=['POST'])
def receive_log():
    raw_log = request.json.get("raw_log")
    raw_log = fix_iso_format(raw_log)

    date_str = datetime.date.today().isoformat()
    filename = f"{DATA_DIR}/{date_str}.json"
    
    type_priority = {"fatal": 0, "error": 1, "warn": 2, "info": 3, "debug": 4}
    log_type = "info"
    for t in type_priority.keys():
        if f"[{t.upper()}]" in raw_log:
            log_type = t
            break

    entry = {
        "content": raw_log, 
        "type": log_type, 
        "priority": type_priority.get(log_type, 5),
        "timestamp": datetime.datetime.now().timestamp()
    }
    
    logs = []
    if os.path.exists(filename):
        with open(filename, "r") as f:
            try: logs = json.load(f)
            except: pass
    
    logs.append(entry)
    with open(filename, "w") as f:
        json.dump(logs, f, indent=4)

    socketio.emit('new_log', entry)
    return {"status": "ok"}, 200

@app.route('/api/logs/<date_val>')
def get_specific_logs(date_val):
    filename = f"{DATA_DIR}/{date_val}.json"
    if os.path.exists(filename):
        with open(filename, "r") as f:
            return jsonify(json.load(f))
    return jsonify([])

@app.route('/')
def index():
    log_files = get_log_files()
    current_date = datetime.date.today().isoformat()
    
    # FIX 3: Look in /data/ for the initial history load
    filename = f"{DATA_DIR}/{current_date}.json"
    
    history = []
    if os.path.exists(filename):
        with open(filename, "r") as f:
            try: history = json.load(f)
            except: pass
            
    return render_template("index.html", history=history, log_files=log_files, current_date=current_date)

if __name__ == '__main__':
    # Use standard run or eventlet depending on your environment
    socketio.run(app, host='127.0.0.1', port=51000, debug=True)