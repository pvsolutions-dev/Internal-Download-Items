import datetime
import requests
import random
import time

class Logger:
    def __init__(self, server_url="http://127.0.0.1:51000/api/log"):
        self.server_url = server_url

    def log(self, msg, types):
        ts = datetime.datetime.now().isoformat()
        log_string = f"[{ts}] - [{types.upper()}] - {msg}"
        print(log_string)
        
        try:
            requests.post(self.server_url, json={"raw_log": log_string}, timeout=2)
        except:
            pass

    def fatal(self, msg): self.log(msg, "fatal")
    def error(self, msg): self.log(msg, "error")
    def warn(self, msg):  self.log(msg, "warn")
    def info(self, msg):  self.log(msg, "info")
    def debug(self, msg): self.log(msg, "debug")

# --- FIX START ---
# Create the instance here
logger = Logger() 

while True:
    x = random.randint(1, 5)
    # Use 'logger' (lowercase) to refer to the instance
    if x == 1:
        logger.fatal("Critical failure!")
    elif x == 2:
        logger.error("Something went wrong.")
    elif x == 3:
        logger.warn("Warning issued.")
    elif x == 4:
        logger.info("System is stable.")
    elif x == 5:
        logger.debug("Debugging trace.")
    
    time.sleep(1)
# --- FIX END ---